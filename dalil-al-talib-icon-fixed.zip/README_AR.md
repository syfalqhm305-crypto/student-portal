# دليل الطالب — مشروع Android

تم ضبط هوية التطبيق باسم **دليل الطالب** مع شاشة بداية كحلية وذهبية تحتوي على شعار كتاب + قبعة تخرج، ثم انتقال ناعم إلى الموقع.

## البناء

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

بعدها من Android Studio:
**Build → Build APK(s)**

اسم التطبيق: دليل الطالب  
App ID: `com.dalilaltalib.app`

ملاحظة: شاشة البداية المضمنة في الموقع تظهر مباشرة عند بدء الواجهة، كما تم إعداد Capacitor Splash Screen ليعمل عند إنشاء مشروع Android عبر `cap sync`.

import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.dalilaltalib.app',
  appName: 'دليل الطالب',
  webDir: 'www',
  bundledWebRuntime: false,

  plugins: {
    SplashScreen: {
      launchAutoHide: true,
      launchShowDuration: 1800,
      backgroundColor: '#071426',
      androidScaleType: 'CENTER',
      showSpinner: false
    }
  },

  android: {
    allowMixedContent: false
  }
};

export default config;
